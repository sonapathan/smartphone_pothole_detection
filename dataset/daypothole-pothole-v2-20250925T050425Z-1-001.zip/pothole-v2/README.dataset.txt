# Pothole Detection  > 2025-06-24 2:18pm
https://universe.roboflow.com/sona-dmcnv/pothole-detection-i00zy-kqcwd

Provided by a Roboflow user
License: CC BY 4.0

